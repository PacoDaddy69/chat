$(document).ready(function() {
	console.log("Loaded");
	var clicks = 0;

	var fbRef = new Firebase("https://dazzling-heat-8742.firebaseio.com/");

	fbRef.child('clicks').on('value', function(snapshot) {
		console.log(snapshot.val());
		clicks = snapshot.val();
		$('#clicks').text(clicks);
	});

	

	$('#cookie').click(function() {
		clicks = clicks + 1;
		$('#clicks').text(clicks);
	});

	$('#reset').click(function() {
		clicks = 0;
		$('#clicks').text(clicks);
	})

});